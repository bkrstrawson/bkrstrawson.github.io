// OOP Pair Programming Starter Code
// Your Names
// The Date


// ------------------------------------------------------------------------- //
// You don't need to edit this section...

let enterprise;
let shipImage, bulletImage;
let theBullets = [];

function preload() {
  shipImage = loadImage("assets/enterprise.png");
  bulletImage = loadImage("assets/laser-shot.png");
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  enterprise = new Ship(width/2, height/2, shipImage);
}

function draw() {
  background("black");
 
  for (let i = theBullets.length-1; i>0; i--){
    theBullets[i].display();
    theBullets[i].update();
    if(theBullets[i].isOnScreen()){
      theBullets.splice(i,1);
    }
  }
  enterprise.update();
  enterprise.display();
}

function keyPressed() {
  enterprise.handleKeyPress();
}

// ------------------------------------------------------------------------- //
// Start editing here!

class Ship {
  constructor(x, y, theImage) {
    this.x = x;
    this.y = y;
    this.image = theImage;
    this.speed = 6;
  }

  update() {
    if(keyIsDown(87)) { // W
      this.y -= this.speed;
    }
    if(keyIsDown(68)) { // D
      this.x += this.speed;
    }
    if(keyIsDown(65)) { // A
      this.x -= this.speed;
    }
    if(keyIsDown(83)) { // S
      this.y += this.speed;
    }
  }

  display() {
    image(this.image, this.x, this.y);
  }

  handleKeyPress(other) {
    if (keyIsDown(32)) {
      let bullet = new Bullet(this.x + this.image.width/2,this.y,0,8,bulletImage);
      theBullets.push(bullet);
    }
  }
}

// ------------------------------------------------------------------------- //

// Extra for Experts 
//  - you can instantiate a bullet (or a bullet array) within the Ship class,
//    and call the display and update functions in the logical location of the 
//    Ship class. If you create an array of bullets, you might want to think about
//    when the bullets should be removed from the array...

class Bullet {
  constructor(x, y, dx, dy, theImage) {
    this.x = x;
    this.y = y;
    this.dx = dx;
    this.dy = dy;
    this.image = theImage;
  }

  update() {
    this.y -= this.dy;
  }

  display() {
    image(this.image,this.x-this.image.width/2,this.y);
  }

  isOnScreen() {
    return this.y < 0;
  }
}

